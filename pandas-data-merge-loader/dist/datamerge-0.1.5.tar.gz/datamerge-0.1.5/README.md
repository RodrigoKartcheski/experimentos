# Requisitos de Instalação

- Python >=3.7 <3.11
- Biblioteca Exemplo versão 1.2.3

Para instalar as dependências, execute o seguinte comando no terminal:
